# SKM Black-Scholes
## This is a Black-Scholes Options calculator built in Python
#### Input the ticker, days to option expiry, and desired strike price into the funciton
#### The calculator will provide the options price, according to Black-Scholes, as well as visual plots to provide support for calculations and deciison-making
###### This project is built from the Black-Scholes formula, however, there are no guarntees of accuracy, as such, liability and warranty are limited per the lICENSE